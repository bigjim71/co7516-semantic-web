package com.boating.rest;

/**
 * Created by fh231 on 4/27/2018.
 */
public class Boat {

    private String name;
    private int size;

    public Boat(String name) {
        this.name = name;
    }


}
